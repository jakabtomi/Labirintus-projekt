﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace LabirintusSzerkeszto
{
    class Program
    {
        static void Main(string[] args)
        {
            // Konzol beállítása UTF-8 karakterek támogatásához (keretrajzolók, stb.)
            Console.OutputEncoding = Encoding.UTF8;
            Console.CursorVisible = false;  // ne villogjon a kurzor

            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== LABIRINTUS SZERKESZTŐ ===");
                Console.WriteLine("1. Új labirintus létrehozása");
                Console.WriteLine("2. Labirintus betöltése fájlból");
                Console.WriteLine("3. Kilépés");
                Console.Write("Választás: ");
                string valasztas = Console.ReadLine();

                if (valasztas == "1")
                {
                    // Új labirintus létrehozása
                    int szelesseg = BeolvasEgesz("Szélesség: ", 3, 80);
                    int magassag = BeolvasEgesz("Magasság: ", 3, 40);
                    char[,] ujMaze = new char[magassag, szelesseg];
                    // Feltöltés '.' karakterrel (járatok közötti rész)
                    for (int i = 0; i < magassag; i++)
                        for (int j = 0; j < szelesseg; j++)
                            ujMaze[i, j] = '.';
                    string fajlNev = "ujlabirintus.txt";
                    SzerkesztoFuttatas(ujMaze, fajlNev);
                }
                else if (valasztas == "2")
                {
                    Console.Write("Fájlnév (pl. minta.txt): ");
                    string fajlNev = Console.ReadLine();
                    if (string.IsNullOrWhiteSpace(fajlNev))
                    {
                        Console.WriteLine("Érvénytelen fájlnév!");
                        Console.ReadKey(true);
                        continue;
                    }
                    char[,] betoltottMaze = BetoltMazet(fajlNev);
                    if (betoltottMaze != null)
                    {
                        SzerkesztoFuttatas(betoltottMaze, fajlNev);
                    }
                    else
                    {
                        Console.WriteLine("A fájl betöltése sikertelen!");
                        Console.ReadKey(true);
                    }
                }
                else if (valasztas == "3")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Érvénytelen választás!");
                    Console.ReadKey(true);
                }
            }
        }

        /// <summary>
        /// Segédmetódus egész szám beolvasására min és max között.
        /// </summary>
        static int BeolvasEgesz(string prompt, int min, int max)
        {
            int ertek;
            while (true)
            {
                Console.Write(prompt);
                if (int.TryParse(Console.ReadLine(), out ertek) && ertek >= min && ertek <= max)
                    return ertek;
                Console.WriteLine($"Kérlek {min} és {max} közötti számot adj meg!");
            }
        }

        /// <summary>
        /// Labirintus betöltése szöveges fájlból.
        /// </summary>
        static char[,] BetoltMazet(string fajlNev)
        {
            try
            {
                if (!File.Exists(fajlNev))
                {
                    Console.WriteLine($"A fájl nem létezik: {fajlNev}");
                    return null;
                }

                string[] sorok = File.ReadAllLines(fajlNev, Encoding.UTF8);
                if (sorok.Length == 0)
                {
                    Console.WriteLine("A fájl üres.");
                    return null;
                }

                int magassag = sorok.Length;
                int szelesseg = 0;
                // Megkeressük a leghosszabb sort
                foreach (string sor in sorok)
                    if (sor.Length > szelesseg)
                        szelesseg = sor.Length;

                char[,] maze = new char[magassag, szelesseg];
                // Feltöltés alapértelmezett '.' karakterrel, majd sorok beolvasása
                for (int i = 0; i < magassag; i++)
                    for (int j = 0; j < szelesseg; j++)
                        maze[i, j] = '.';

                for (int i = 0; i < sorok.Length; i++)
                {
                    string sor = sorok[i];
                    for (int j = 0; j < sor.Length; j++)
                    {
                        maze[i, j] = sor[j];
                    }
                }
                return maze;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba a betöltés során: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Labirintus mentése fájlba.
        /// </summary>
        static void MentMazet(char[,] maze, string fajlNev)
        {
            try
            {
                int magassag = maze.GetLength(0);
                int szelesseg = maze.GetLength(1);
                string[] sorok = new string[magassag];
                for (int i = 0; i < magassag; i++)
                {
                    StringBuilder sb = new StringBuilder();
                    for (int j = 0; j < szelesseg; j++)
                        sb.Append(maze[i, j]);
                    sorok[i] = sb.ToString();
                }

                // Abszolút elérési út meghatározása
                string teljesFajlNev = Path.IsPathRooted(fajlNev) 
                    ? fajlNev 
                    : Path.Combine(Environment.CurrentDirectory, fajlNev);

                File.WriteAllLines(teljesFajlNev, sorok, Encoding.UTF8);
                Console.WriteLine($"Sikeres mentés!");
                Console.WriteLine($"Hely: {teljesFajlNev}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba a mentés során: {ex.Message}");
            }
        }

        /// <summary>
        /// A szerkesztő felület futtatása.
        /// </summary>
        static void SzerkesztoFuttatas(char[,] maze, string fajlNev)
        {
            int magassag = maze.GetLength(0);
            int szelesseg = maze.GetLength(1);
            int kurzorX = 0;
            int kurzorY = 0;

            // Karakter leképezés a könnyű beszúráshoz (számok és néhány betű)
            Dictionary<char, char> karakterLekepzes = new Dictionary<char, char>
            {
                {'1', '╬'}, {'2', '═'}, {'3', '╦'}, {'4', '╩'}, {'5', '║'},
                {'6', '╣'}, {'7', '╠'}, {'8', '╗'}, {'9', '╝'}, {'0', '╚'},
                {'q', '╔'}, {'w', '.'}, {'e', '█'}
            };

            // Engedélyezett karakterek halmaza (érvényes labirintus karakterek)
            HashSet<char> engedelyezett = new HashSet<char>
            {
                '╬','═','╦','╩','║','╣','╠','╗','╝','╚','╔', '.', '█'
            };

            // Konzolablak átméretezése a jobb megjelenítés érdekében
            try
            {
                int ablakSzelesseg = Math.Min(Console.LargestWindowWidth, szelesseg + 5);
                int ablakMagassag = Math.Min(Console.LargestWindowHeight, magassag + 12);
                Console.SetWindowSize(ablakSzelesseg, ablakMagassag);
            }
            catch { /* Ha nem sikerül, dolgozunk tovább */ }

            bool szerkeszt = true;
            while (szerkeszt)
            {
                // Térkép kirajzolása
                RajzolMazet(maze, kurzorX, kurzorY);

                // Státuszsor és súgó kijelzése
                Console.WriteLine();
                Console.WriteLine($"Pozíció: ({kurzorX},{kurzorY})  Karakter: {maze[kurzorY, kurzorX]}");
                Console.WriteLine();
                Console.WriteLine("┌─ MOZGÁS ─────────────┬─ KARAKTEREK ─────────────────────────────────┐");
                Console.WriteLine("│ W/↑=Fel  S/↓=Le      │ 1:╬  2:═  3:╦  4:╩  5:║  6:╣  7:╠  8:╗      │");
                Console.WriteLine("│ A/←=Bal  D/→=Jobb    │ 9:╝  0:╚  Q:╔  W:.  E:█                   │");
                Console.WriteLine("├──────────────────────┼──────────────────────────────────────────────┤");
                Console.WriteLine("│ Ctrl+S: Mentés       │ Ctrl+O: Betöltés  Ctrl+N: Új  Esc: Kilépés│");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("│ PIROS = érvénytelen kapcsolat                                      │");
                Console.ResetColor();
                Console.WriteLine("└──────────────────────┴──────────────────────────────────────────────┘");
                Console.Write("Nyomj egy gombot: ");

                // Billentyű beolvasása
                ConsoleKeyInfo bill = Console.ReadKey(true);

                // Ctrl kombinációk
                if ((bill.Modifiers & ConsoleModifiers.Control) != 0)
                {
                    switch (bill.Key)
                    {
                        case ConsoleKey.S:
                            MentMazet(maze, fajlNev);
                            Console.WriteLine($"\nSikeres mentés: {fajlNev}");
                            Console.WriteLine("Nyomj egy gombot a folytatáshoz...");
                            Console.ReadKey(true);
                            break;
                        case ConsoleKey.O:
                            Console.Write("\nBetöltendő fájl neve: ");
                            string ujFajl = Console.ReadLine();
                            if (!string.IsNullOrEmpty(ujFajl))
                            {
                                char[,] ujMaze = BetoltMazet(ujFajl);
                                if (ujMaze != null)
                                {
                                    maze = ujMaze;
                                    magassag = maze.GetLength(0);
                                    szelesseg = maze.GetLength(1);
                                    fajlNev = ujFajl;
                                    kurzorX = 0; kurzorY = 0;
                                    Console.WriteLine("Sikeres betöltés!");
                                }
                            }
                            Console.WriteLine("Nyomj egy gombot a folytatáshoz...");
                            Console.ReadKey(true);
                            break;
                        case ConsoleKey.N:
                            int ujSz = BeolvasEgesz("Új szélesség: ", 3, 80);
                            int ujMa = BeolvasEgesz("Új magasság: ", 3, 40);
                            maze = new char[ujMa, ujSz];
                            for (int i = 0; i < ujMa; i++)
                                for (int j = 0; j < ujSz; j++)
                                    maze[i, j] = '.';
                            magassag = ujMa;
                            szelesseg = ujSz;
                            kurzorX = 0; kurzorY = 0;
                            fajlNev = "ujlabirintus.txt";
                            Console.WriteLine("Új üres labirintus létrehozva.");
                            Console.ReadKey(true);
                            break;
                    }
                    continue; // Ctrl után újrarajzolás
                }

                // Mozgás kezelése
                int ujX = kurzorX;
                int ujY = kurzorY;
                switch (bill.Key)
                {
                    case ConsoleKey.UpArrow:
                    case ConsoleKey.W: ujY--; break;
                    case ConsoleKey.DownArrow:
                    case ConsoleKey.S: ujY++; break;
                    case ConsoleKey.LeftArrow:
                    case ConsoleKey.A: ujX--; break;
                    case ConsoleKey.RightArrow:
                    case ConsoleKey.D: ujX++; break;
                    case ConsoleKey.Escape:
                        szerkeszt = false;
                        continue;
                }
                // Határok ellenőrzése
                if (ujX >= 0 && ujX < szelesseg && ujY >= 0 && ujY < magassag)
                {
                    kurzorX = ujX;
                    kurzorY = ujY;
                }

                // Karakter beszúrása (ha a lenyomott billentyű szerepel a leképezésben)
                char beirt = bill.KeyChar;
                if (karakterLekepzes.ContainsKey(beirt))
                {
                    char ujChar = karakterLekepzes[beirt];
                    maze[kurzorY, kurzorX] = ujChar;
                }
                // Ha közvetlenül érvényes karaktert ütött be (pl. másolás/illesztés)
                else if (engedelyezett.Contains(beirt))
                {
                    maze[kurzorY, kurzorX] = beirt;
                }
            }
        }

        /// <summary>
        /// Egy karakter lehetséges irányait adja vissza (melyik oldalra nyílik).
        /// Irányok: 0=fel, 1=jobb, 2=le, 3=bal
        /// </summary>
        static bool[] GetIranyok(char kar)
        {
            // fel, jobb, le, bal
            return kar switch
            {
                '╬' => new[] { true, true, true, true },   // minden irányba
                '═' => new[] { false, true, false, true }, // vízszintes
                '║' => new[] { true, false, true, false }, // függőleges
                '╦' => new[] { false, true, true, true },  // bal, jobb, le (fel nincs)
                '╩' => new[] { true, true, false, true },  // fel, jobb, bal (le nincs)
                '╗' => new[] { true, false, true, true },  // fel, le, bal (jobb nincs)
                '╚' => new[] { true, true, false, false }, // fel, jobb (bal, le nincs)
                '╝' => new[] { false, true, true, false }, // jobb, le (fel, bal nincs)
                '╔' => new[] { false, true, true, false }, // jobb, le (fel, bal nincs)
                '╣' => new[] { true, false, true, true },  // fel, le, bal (jobb nincs)
                '╠' => new[] { true, true, true, false },  // fel, jobb, le (bal nincs)
                _ => new[] { false, false, false, false }  // más karakterek: nincs irány
            };
        }

        /// <summary>
        /// Ellenőrzi, hogy az adott pozícióban lévő karakter valós kapcsolatokkal rendelkezik.
        /// Visszaadja az érvényes irányokat.
        /// </summary>
        static bool[] GetErvenyesIranyok(char[,] maze, int x, int y)
        {
            int magassag = maze.GetLength(0);
            int szelesseg = maze.GetLength(1);

            bool[] iranyok = GetIranyok(maze[y, x]);
            bool[] ervenyesIranyok = new bool[4]; // fel, jobb, le, bal

            // Jelöljük meg az irányokat azoknál amelyeknél valóban csatlakozik járatkarakter
            // Fel (0)
            if (iranyok[0] && y > 0)
            {
                char fenti = maze[y - 1, x];
                bool[] fentiIranyok = GetIranyok(fenti);
                ervenyesIranyok[0] = fentiIranyok[2]; // a felette lévő le felé nyílik?
            }

            // Jobb (1)
            if (iranyok[1] && x < szelesseg - 1)
            {
                char jobb = maze[y, x + 1];
                bool[] jobbIranyok = GetIranyok(jobb);
                ervenyesIranyok[1] = jobbIranyok[3]; // a jobb oldali bal felé nyílik?
            }

            // Le (2)
            if (iranyok[2] && y < magassag - 1)
            {
                char lenti = maze[y + 1, x];
                bool[] lentiIranyok = GetIranyok(lenti);
                ervenyesIranyok[2] = lentiIranyok[0]; // a lenti fel felé nyílik?
            }

            // Bal (3)
            if (iranyok[3] && x > 0)
            {
                char bal = maze[y, x - 1];
                bool[] balIranyok = GetIranyok(bal);
                ervenyesIranyok[3] = balIranyok[1]; // a bal oldali jobb felé nyílik?
            }

            return ervenyesIranyok;
        }

        /// <summary>
        /// A labirintus kirajzolása a konzolra, a kurzor pozíciójának kiemelésével.
        /// Az érvénytelen irányokat piros színnel jelöli.
        /// </summary>
        static void RajzolMazet(char[,] maze, int kurzorX, int kurzorY)
        {
            Console.Clear();
            int magassag = maze.GetLength(0);
            int szelesseg = maze.GetLength(1);

            for (int i = 0; i < magassag; i++)
            {
                for (int j = 0; j < szelesseg; j++)
                {
                    if (j == kurzorX && i == kurzorY)
                    {
                        // Kurzor kiemelése (szürke háttér)
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.Write(maze[i, j]);
                        Console.ResetColor();
                    }
                    else
                    {
                        // Ellenőrizzük, hogy az adott karakter valós irányokkal rendelkezik
                        bool[] iranyok = GetIranyok(maze[i, j]);
                        bool[] ervenyesIranyok = GetErvenyesIranyok(maze, j, i);

                        // Ha van olyan irány, ami nem érvényes, piros színben jelezzük
                        bool vanHiba = false;
                        for (int k = 0; k < 4; k++)
                        {
                            if (iranyok[k] && !ervenyesIranyok[k])
                            {
                                vanHiba = true;
                                break;
                            }
                        }

                        if (vanHiba && "╬═║╦╩╗╚╝╣╠╔".Contains(maze[i, j]))
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write(maze[i, j]);
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.Write(maze[i, j]);
                        }
                    }
                }
                Console.WriteLine();
            }
        }
    }
}